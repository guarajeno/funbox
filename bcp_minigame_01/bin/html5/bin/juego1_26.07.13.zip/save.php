<?php

$score = $_REQUEST["score"];
$user  = $_REQUEST["user"];
/* aquie debes poner lo necesario para poder guardar a una BD*/
echo "u:".$user.";score:".$score;

?>

